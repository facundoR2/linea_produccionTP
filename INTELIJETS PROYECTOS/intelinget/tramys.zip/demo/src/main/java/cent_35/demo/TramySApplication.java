package cent_35.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TramySApplication {

	public static void main(String[] args) {
		SpringApplication.run(TramySApplication.class, args);
	}

}
