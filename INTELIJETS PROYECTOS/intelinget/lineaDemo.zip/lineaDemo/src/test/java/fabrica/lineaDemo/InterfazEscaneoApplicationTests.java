package fabrica.lineaDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterfazEscaneoApplicationTests {

	@Test
	void contextLoads() {
	}

}
