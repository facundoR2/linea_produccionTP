package fabrica.lineaDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterfazEscaneoApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterfazEscaneoApplication.class, args);
	}

}
