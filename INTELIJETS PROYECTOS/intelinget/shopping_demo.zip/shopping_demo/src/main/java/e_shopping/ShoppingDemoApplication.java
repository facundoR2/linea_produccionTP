package e_shopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingDemoApplication.class, args);
	}

}
